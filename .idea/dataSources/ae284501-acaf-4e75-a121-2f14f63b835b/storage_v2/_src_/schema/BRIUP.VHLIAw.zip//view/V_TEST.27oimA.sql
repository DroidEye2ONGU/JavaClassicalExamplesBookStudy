create view V_TEST as
  select "ID","NAME","SALARY"
from t_user
where id > 10
/

